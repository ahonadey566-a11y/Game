/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package javagame;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class javagame extends javax.swing.JFrame {
    boolean xTurn = true;
int xCount = 0;
int oCount = 0;
void resetBoard() {
    txtbtn1.setText("");
    txtbtn2.setText("");
    txtbtn3.setText("");
    txtbtn4.setText("");
    txtbtn5.setText("");
    txtbtn6.setText("");
    txtbtn7.setText("");
    txtbtn8.setText("");
    txtbtn9.setText("");

    xTurn = true;
}
void checkWinner() {

    String b1 = txtbtn1.getText();
    String b2 = txtbtn2.getText();
    String b3 = txtbtn3.getText();
    String b4 = txtbtn4.getText();
    String b5 = txtbtn5.getText();
    String b6 = txtbtn6.getText();
    String b7 = txtbtn7.getText();
    String b8 = txtbtn8.getText();
    String b9 = txtbtn9.getText();

    // X WIN
    if (
        (b1.equals("X") && b2.equals("X") && b3.equals("X")) ||
        (b4.equals("X") && b5.equals("X") && b6.equals("X")) ||
        (b7.equals("X") && b8.equals("X") && b9.equals("X")) ||
        (b1.equals("X") && b4.equals("X") && b7.equals("X")) ||
        (b2.equals("X") && b5.equals("X") && b8.equals("X")) ||
        (b3.equals("X") && b6.equals("X") && b9.equals("X")) ||
        (b1.equals("X") && b5.equals("X") && b9.equals("X")) ||
        (b3.equals("X") && b5.equals("X") && b7.equals("X"))
    ) {
        xCount++;
       IBIX.setText("Player X : " + xCount);
        JOptionPane.showMessageDialog(this, "Player X Wins!");
        resetBoard();
    }

    // O WIN
    if (
        (b1.equals("O") && b2.equals("O") && b3.equals("O")) ||
        (b4.equals("O") && b5.equals("O") && b6.equals("O")) ||
        (b7.equals("O") && b8.equals("O") && b9.equals("O")) ||
        (b1.equals("O") && b4.equals("O") && b7.equals("O")) ||
        (b2.equals("O") && b5.equals("O") && b8.equals("O")) ||
        (b3.equals("O") && b6.equals("O") && b9.equals("O")) ||
        (b1.equals("O") && b5.equals("O") && b9.equals("O")) ||
        (b3.equals("O") && b5.equals("O") && b7.equals("O"))
    ) {
        oCount++;
        IBIO.setText("Player O : " + oCount);
        JOptionPane.showMessageDialog(this, "Player O Wins!");
        resetBoard();
    }
}


    
    public javagame() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtbtn1 = new javax.swing.JButton();
        txtbtn4 = new javax.swing.JButton();
        txtbtn2 = new javax.swing.JButton();
        txtbtn7 = new javax.swing.JButton();
        txtbtn5 = new javax.swing.JButton();
        txtbtn3 = new javax.swing.JButton();
        txtbtn6 = new javax.swing.JButton();
        txtbtn9 = new javax.swing.JButton();
        txtbtn8 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        txtbtnexit = new javax.swing.JButton();
        txtbtnreset = new javax.swing.JButton();
        IBIX = new javax.swing.JLabel();
        IBIO = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("tic tac toe");

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setForeground(new java.awt.Color(0, 0, 255));
        jPanel1.setToolTipText("");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("TIC TAC TOE");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(268, 268, 268)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        txtbtn1.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        txtbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbtn1ActionPerformed(evt);
            }
        });

        txtbtn4.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        txtbtn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbtn4ActionPerformed(evt);
            }
        });

        txtbtn2.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        txtbtn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbtn2ActionPerformed(evt);
            }
        });

        txtbtn7.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        txtbtn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbtn7ActionPerformed(evt);
            }
        });

        txtbtn5.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        txtbtn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbtn5ActionPerformed(evt);
            }
        });

        txtbtn3.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        txtbtn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbtn3ActionPerformed(evt);
            }
        });

        txtbtn6.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        txtbtn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbtn6ActionPerformed(evt);
            }
        });

        txtbtn9.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        txtbtn9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbtn9ActionPerformed(evt);
            }
        });

        txtbtn8.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        txtbtn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbtn8ActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));

        txtbtnexit.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        txtbtnexit.setForeground(new java.awt.Color(0, 153, 0));
        txtbtnexit.setText("Exit");
        txtbtnexit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbtnexitActionPerformed(evt);
            }
        });

        txtbtnreset.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        txtbtnreset.setForeground(new java.awt.Color(0, 153, 153));
        txtbtnreset.setText("Reset");
        txtbtnreset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbtnresetActionPerformed(evt);
            }
        });

        IBIX.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        IBIX.setText("Player X :");
        IBIX.setOpaque(true);

        IBIO.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        IBIO.setText("Player O :");
        IBIO.setOpaque(true);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(28, 198, Short.MAX_VALUE)
                .addComponent(txtbtnexit, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(IBIO)
                    .addComponent(IBIX))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(24, 24, 24)
                    .addComponent(txtbtnreset, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(198, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(IBIX)
                .addGap(87, 87, 87)
                .addComponent(IBIO)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 111, Short.MAX_VALUE)
                .addComponent(txtbtnexit, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                    .addContainerGap(323, Short.MAX_VALUE)
                    .addComponent(txtbtnreset, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(22, 22, 22)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtbtn1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtbtn4, javax.swing.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                            .addComponent(txtbtn7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtbtn8, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtbtn5, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtbtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtbtn9, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtbtn3, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtbtn6, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(11, 11, 11)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtbtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtbtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtbtn3, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtbtn4, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtbtn5, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtbtn6, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(txtbtn8, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtbtn7, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtbtn9, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtbtnexitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbtnexitActionPerformed
        // TODO add your handling code here:
         JFrame frame = new JFrame("Exit");
           int response = JOptionPane.showConfirmDialog(
            frame,
            "Confirm if you want Exit",
            "TIC TAC TOE",
            JOptionPane.YES_NO_OPTION
    );

    if (response == JOptionPane.YES_OPTION) {
        System.exit(0);
    }
    }//GEN-LAST:event_txtbtnexitActionPerformed

    private void txtbtnresetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbtnresetActionPerformed
        // TODO add your handling code here:
         {

    txtbtn1.setText("");
    txtbtn2.setText("");
    txtbtn3.setText("");
    txtbtn4.setText("");
    txtbtn5.setText("");
    txtbtn6.setText("");
    txtbtn7.setText("");
    txtbtn8.setText("");
    txtbtn9.setText("");

    txtbtn1.setBackground(Color.LIGHT_GRAY);
     txtbtn2.setBackground(Color.LIGHT_GRAY);
    txtbtn3.setBackground(Color.LIGHT_GRAY);
    txtbtn4.setBackground(Color.LIGHT_GRAY);
    txtbtn5.setBackground(Color.LIGHT_GRAY);
    txtbtn6.setBackground(Color.LIGHT_GRAY);
    txtbtn7.setBackground(Color.LIGHT_GRAY);
    txtbtn8.setBackground(Color.LIGHT_GRAY);
    txtbtn9.setBackground(Color.LIGHT_GRAY);
}
    }//GEN-LAST:event_txtbtnresetActionPerformed

    private void txtbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbtn1ActionPerformed
       if (txtbtn1.getText().equals("")) {
    if (xTurn) {
        txtbtn1.setText("X");
        txtbtn1.setForeground(Color.RED);   // X = Red
    } else {
        txtbtn1.setText("O");
        txtbtn1.setForeground(Color.BLUE);  // O = Blue
    }
    xTurn = !xTurn;
    checkWinner();
}
    }//GEN-LAST:event_txtbtn1ActionPerformed

    private void txtbtn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbtn2ActionPerformed
       if (txtbtn2.getText().equals("")) {
    if (xTurn) {
        txtbtn2.setText("X");
        txtbtn2.setForeground(Color.RED);   // X = Red
    } else {
        txtbtn2.setText("O");
        txtbtn2.setForeground(Color.BLUE);  // O = Blue
    }
    xTurn = !xTurn;
    checkWinner();
}
    }//GEN-LAST:event_txtbtn2ActionPerformed

    private void txtbtn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbtn3ActionPerformed
        if (txtbtn3.getText().equals("")) {
    if (xTurn) {
        txtbtn3.setText("X");
        txtbtn3.setForeground(Color.RED);   // X = Red
    } else {
        txtbtn3.setText("O");
        txtbtn3.setForeground(Color.BLUE);  // O = Blue
    }
    xTurn = !xTurn;
    checkWinner();
}
    }//GEN-LAST:event_txtbtn3ActionPerformed

    private void txtbtn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbtn4ActionPerformed
        if (txtbtn4.getText().equals("")) {
    if (xTurn) {
        txtbtn4.setText("X");
        txtbtn4.setForeground(Color.RED);   // X = Red
    } else {
        txtbtn4.setText("O");
        txtbtn4.setForeground(Color.BLUE);  // O = Blue
    }
    xTurn = !xTurn;
    checkWinner();
}
    }//GEN-LAST:event_txtbtn4ActionPerformed

    private void txtbtn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbtn5ActionPerformed
        if (txtbtn5.getText().equals("")) {
    if (xTurn) {
        txtbtn5.setText("X");
        txtbtn5.setForeground(Color.RED);   // X = Red
    } else {
        txtbtn5.setText("O");
        txtbtn5.setForeground(Color.BLUE);  // O = Blue
    }
    xTurn = !xTurn;
    checkWinner();
}
    }//GEN-LAST:event_txtbtn5ActionPerformed

    private void txtbtn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbtn6ActionPerformed
      if (txtbtn6.getText().equals("")) {
    if (xTurn) {
        txtbtn6.setText("X");
        txtbtn6.setForeground(Color.RED);   // X = Red
    } else {
        txtbtn6.setText("O");
        txtbtn6.setForeground(Color.BLUE);  // O = Blue
    }
    xTurn = !xTurn;
    checkWinner();
}
    }//GEN-LAST:event_txtbtn6ActionPerformed

    private void txtbtn7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbtn7ActionPerformed
       if (txtbtn7.getText().equals("")) {
    if (xTurn) {
        txtbtn7.setText("X");
        txtbtn7.setForeground(Color.RED);   // X = Red
    } else {
        txtbtn7.setText("O");
        txtbtn7.setForeground(Color.BLUE);  // O = Blue
    }
    xTurn = !xTurn;
    checkWinner();
}
    }//GEN-LAST:event_txtbtn7ActionPerformed

    private void txtbtn8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbtn8ActionPerformed
       if (txtbtn8.getText().equals("")) {
    if (xTurn) {
        txtbtn8.setText("X");
        txtbtn8.setForeground(Color.RED);   // X = Red
    } else {
        txtbtn8.setText("O");
        txtbtn8.setForeground(Color.BLUE);  // O = Blue
    }
    xTurn = !xTurn;
    checkWinner();
}
    }//GEN-LAST:event_txtbtn8ActionPerformed

    private void txtbtn9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbtn9ActionPerformed
        if (txtbtn9.getText().equals("")) {
    if (xTurn) {
        txtbtn9.setText("X");
        txtbtn9.setForeground(Color.RED);   // X = Red
    } else {
        txtbtn9.setText("O");
        txtbtn9.setForeground(Color.BLUE);  // O = Blue
    }
    xTurn = !xTurn;
    checkWinner();
}
    }//GEN-LAST:event_txtbtn9ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(javagame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(javagame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(javagame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(javagame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new javagame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel IBIO;
    private javax.swing.JLabel IBIX;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton txtbtn1;
    private javax.swing.JButton txtbtn2;
    private javax.swing.JButton txtbtn3;
    private javax.swing.JButton txtbtn4;
    private javax.swing.JButton txtbtn5;
    private javax.swing.JButton txtbtn6;
    private javax.swing.JButton txtbtn7;
    private javax.swing.JButton txtbtn8;
    private javax.swing.JButton txtbtn9;
    private javax.swing.JButton txtbtnexit;
    private javax.swing.JButton txtbtnreset;
    // End of variables declaration//GEN-END:variables
}
